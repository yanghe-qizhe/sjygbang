//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ϵͳ���ܰ�ť��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.06.25 09:16</date>
    /// </author>
    /// </summary>
    public class Base_ModuleButtonBll : RepositoryFactory<Base_ModuleButton>
    {
    }
}