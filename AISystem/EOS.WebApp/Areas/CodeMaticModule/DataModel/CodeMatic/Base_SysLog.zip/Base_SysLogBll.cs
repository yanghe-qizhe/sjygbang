//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2016
// Software Developers @ Learun 2016
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ϵͳ��־��
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.05.13 14:31</date>
    /// </author>
    /// </summary>
    public class Base_SysLogBll : RepositoryFactory<Base_SysLog>
    {
    }
}