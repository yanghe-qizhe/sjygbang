//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// �Զ�������ģ��
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.05.04 11:38</date>
    /// </author>
    /// </summary>
    public class WF_FlowMainBll : RepositoryFactory<WF_FlowMain>
    {
    }
}