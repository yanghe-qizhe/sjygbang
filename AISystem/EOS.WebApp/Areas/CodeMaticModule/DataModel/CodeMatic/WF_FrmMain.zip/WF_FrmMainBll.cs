//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2015
// Software Developers @ Learun 2015
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// ����ģ���
    /// <author>
    ///		<name>she</name>
    ///		<date>2015.04.24 09:23</date>
    /// </author>
    /// </summary>
    public class WF_FrmMainBll : RepositoryFactory<WF_FrmMain>
    {
    }
}